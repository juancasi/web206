package org.software;

public class Calculadora {
	
	public double sumar(double n1, double n2) {
		double resultado = n1 + n2;
		return resultado;
	}
	
	public double restar(double n1, double n2) {
		double resultado = n1 - n2;
		return resultado;
	}
	
	public double multiplicar(double n1, double n2) {
		double resultado = n1 * n2;
		return resultado;
	}
	
	public double dividir(double n1, double n2) {
		double resultado = n1 / n2;
		return resultado;
	}

}
